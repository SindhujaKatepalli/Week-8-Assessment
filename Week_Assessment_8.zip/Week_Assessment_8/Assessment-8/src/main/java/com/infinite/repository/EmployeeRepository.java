package com.infinite.repository;

import org.springframework.stereotype.Repository;

import com.infinite.model.Employee;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee,Integer>{

}

